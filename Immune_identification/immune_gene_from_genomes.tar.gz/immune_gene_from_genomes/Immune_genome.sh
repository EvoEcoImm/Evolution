for i in {"Znev.OGS.v2.2.pep","bger_1.2.1_pep_loIs_PG.fa","Mnat_gene_v1.2.pep.fa"}
do hmmsearch -o "$i".out --domtblout "$i".dom_out.tab --tblout "$i".target_out.tab --noali --notextw -E 1e-5 --domE 1 --incE 0.001 --cpu 4 /media/shulinhe/DATA/immune_database/orthodb_v6/Immune_v6.hmm "$i";
blastp -query "$i" -db /media/shulinhe/DATA/immune_database/orthodb_v6/Immune_v6.fa -num_threads 3 -evalue 0.00001 -max_target_seqs 1 -outfmt 6 -out "$i".blastp.outfmt6;done

for i in {"znev","bger","mnat"}
do python Immune_gene_new_genome.py -i "$i"_clusto.target_out.tab -p "$i".blastp.outfmt6 -o "$i"_linshi.csv;
done

cut -f1 znev_linshi.csv > linshi_immune; xargs samtools faidx Znev.OGS.v2.2.pep < linshi_immune >> linshi_immune.fasta
cut -f1 mnat_linshi.csv > linshi_immune; xargs samtools faidx Mnat_gene_v1.2.pep.fa < linshi_immune >> linshi_immune.fasta
cut -f1 bger_linshi.csv > linshi_immune; xargs samtools faidx bger_1.2.1_pep_loIs_PG.fa < linshi_immune >> linshi_immune.fasta
rm linshi_immune

blastp -query linshi_immune.fasta -db ~/databases/uniprot_sprot.pep -num_threads 3 -evalue 0.00001 -max_target_seqs 1 -outfmt 6 -out genome.uniblastp.outfmt6
cut -f2 genome.uniblastp.outfmt6|sort -u > genome_linshiuniprot;


cat znev_linshi.csv mnat_linshi.csv bger_linshi.csv > genome_linshi.csv
sort -k1,1 genome.uniblastp.outfmt6 -u |awk -F'\t' 'FNR==NR{a[$1]=$2"\t"$11;next}{print $0"\t"a[$1]}' - genome_linshi.csv > Genome_immune_non;
rm genome_linshi.csv znev_linshi.csv mnat_linshi.csv bger_linshi.csv


