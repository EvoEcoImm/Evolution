#! /usr/bin/python

import argparse
import re

def parser():
	args=argparse.ArgumentParser()
	args.add_argument('-i','--input',help='The name of the Hmmsearch output_file.')
	args.add_argument('-p','--blastp',help='The name of the blastp output_file')
	args.add_argument('-o','--output',help='The name of the results output file')
	args=args.parse_args()
	return args


hmmfile = open(parser().input,'rt')
blastpfile= open(parser().blastp, 'rt')
outfile = open(parser().output,'wt')


def hmmfil_dict(file):
	entries= [re.split("  *", entry) for entry in file.read().split('\n') if "#" not in entry and entry]
	spec=[(entry[0],entry[2],float(entry[4]),float(entry[7])) for entry in (entry for entry in entries) if float(entry[4])<=0.00001 and float(entry[7]) <=0.001]
	spec.sort(key=lambda spec:(spec[2],spec[3]),reverse=True)
	adict={entry[0]:entry[1:] for entry in spec}
	return adict

with open("/media/shulinhe/DATA/immune_database/orthodb_v6/Immunedbv6gene2family",'rt') as file:
	g2f_dict={entry[0]:entry[1] for entry in (entry.strip('\n').split('\t') for entry in file.readlines())}


def blastp_dict(file):
	blastplist=[entry.strip('\n').split('\t') for entry in file.readlines()]
	blastp_re=[(entry[0],g2f_dict[entry[1]],float(entry[10])) for entry in blastplist]
	blastp_re.sort(key=lambda blastp_re:blastp_re[2],reverse=True)
	dict={entry[0]:(entry[1],entry[2]) for entry in blastp_re if entry[2]<=0.001}
	return dict

def combhpx(adict,dict):
	ph=[(a,)+b+dict[a] for a,b in (entry for entry in adict.items() if entry[0] in dict.keys()) if b[0]==dict[a][0]]
	return ph

def output_write_out(file, ph):
	for a in ph:
		file.write('%s\n' % "\t".join(str(b) for b in a))
	file.close()

hmmdict=hmmfil_dict(hmmfile)
blastpdict=blastp_dict(blastpfile)
hbp=combhpx(hmmdict, blastpdict)
output_write_out(outfile, hbp)

"""with open("../blastx/Bg_blastx_v4.outfmt6",'rt') as file:
	blastxlist=[entry.strip('\n').split('\t') for entry in file.readlines()]
	blastx_re=[(entry[0],g2f_dict[entry[1]],float(entry[-2])) for entry in blastxlist if float(entry[-2])<=0.001]
	blastx_re.sort(key=lambda blastx_re:blastx_re[2],reverse=True)
	xdict={entry[0]:(entry[1],entry[2]) for entry in blastx_re}



phx=[x+xdict[x[4]] for x in (entry for entry in ph if entry[4] in xdict.keys()) if x[1]==xdict[x[4]][0]]
phx.sort(key=lambda spec:(spec[2],spec[3]),reverse=True)
fdict={entry[0]:entry[1:] for entry in phx}
final=[(a,)+b for a,b in fdict.items()]

isofinal=[entry[-3] for entry in final]


with open("/media/shulinhe/DATA/QuanL/Trinotate_out/Bg_trinotate_annotation_report.xls",'rt') as file:
	ctrinotate=[[entry[0],entry[2],entry[6],entry[7],entry[4]] for entry in (entry.strip('\n').split('\t') for entry in file.readlines()[1:]) if entry[4] in isofinal]



trinotate_edi=[]
for trans,blastx,blastp,pfam,transid in ctrinotate:
	d=[trans,transid]
	if blastp !=".":
		blastp1=[blastp.split('^')[0],blastp.split('^')[4].replace('E:',''),blastp.split('^')[5].replace('RecName: Full=','').replace(';',''),blastp.split('^')[6].split(';')[1].replace(' ','')]
	if blastp ==".":
		blastp1=['.']*4
	if pfam !=".":
		pfam1=[entry.split('^') for entry in pfam.replace('E:','').split('`')]
		pfam1.sort(key=lambda pfam1:float(pfam1[-1]))
		pfams=[pfam1[0][0],pfam1[0][2],pfam1[0][4]]
	if pfam ==".":
		pfams=['.']*3
	d.extend(blastp1+pfams+[blastx])
	trinotate_edi.append(d)


tfinal=[list((entry[0],)+fdict[entry[0]]+tuple(entry[2:8])) for entry in trinotate_edi]
outputlist=[entry[:7]+entry[9:11]+entry[12:] for entry in tfinal]


outputlist=[]
for entry in tfinal:
	if "ATG16" in entry[1]:
		if ("autophagy" in entry[15].lower() or "autophagy" in entry[18].lower()):
			outputlist.append(entry)
	elif "Cactus" in entry[1]:
		if "cactus" in entry[15].lower() or "inhibitor" in entry[15].lower() or "cactus" in entry[18].lower() or "inhibitor" in entry[18].lower() or "relish" in entry[15].lower():
			outputlist.append(entry)
	elif "CLIPs" in entry[1]:
		if "allergen" not in entry[15].lower():
			outputlist.append(entry)
	elif "PPOs" in entry[1]:
		if "allergen" not in entry[15].lower():
			outputlist.append(entry)
	elif "Domeless" in entry[1]:
		if "receptro" in entry[15].lower():
			outputlist.append(entry)
	elif "Hopscoth" in entry[1]:
		if "hopscotch" in entry[15].lower() or "jak" in entry[15].lower():
			outputlist.append(entry)
	elif "Stam" in entry[1]:
		if "adapter" in entry[15].lower():
			outputlist.append(entry)
	elif "Apaf" in entry[1]:
		if "apoptotic" in entry[15].lower():
			outputlist.append(entry)
	elif "JNK" in entry[1]:
		if "interacting" in entry[15].lower():
			outputlist.append(entry)
	elif "Ird5" in entry[1]:
		if "inhibitor" in entry[15].lower() or "kappa" in entry[15].lower() or "relish" in entry[15].lower() or "factor" in entry[15].lower():
			outputlist.append(entry)
	elif "TAK1" in entry[1]:
		if "mitogen" in entry[15].lower() or "kinase kinase kinase" in entry[15].lower():
			outputlist.append(entry)
	elif "SPZ" in entry[1]:
		if "spaetzle" in entry[15].lower():
			outputlist.append(entry)
	else:
		outputlist.append(entry)

output=[entry[:7]+entry[9:11]+entry[12:] for entry in outputlist]

with open("Bg_final2",'wt') as file:
	for a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p in output:
		file.write('%s\t%s\t%.2e\t%.2e\t%s\t%s\t%s\t%.2e\t%s\t%.2e\t%s\t%s\t%s\t%s\t%s\t%s\t\n' % (a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p))

"""









